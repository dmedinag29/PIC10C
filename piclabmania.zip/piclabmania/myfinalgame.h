#ifndef MYFINALGAME_H
#define MYFINALGAME_H

#include<QTimer>
#include <QMainWindow>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QWidget>
#include "bruin.h"
#include "score.h"
#include "lives.h"

//namespace Ui {
//class myfinalgame;
//}

class myfinalgame : public QGraphicsView
{

public:
    myfinalgame(QWidget* parent = nullptr);

    QGraphicsScene* scene;
    bruin* joe_bruin;
    score* myScore;
    lives* myLives;


//private:
//    Ui::myfinalgame *ui;

};


#endif // MYFINALGAME_H

