#include "holdingwidgets.h"
#include "ui_holdingwidgets.h"

holdingwidgets::holdingwidgets(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::holdingwidgets)
{
    ui->setupUi(this);
}

holdingwidgets::~holdingwidgets()
{
    delete ui;
}
