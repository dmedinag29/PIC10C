#include "lives.h"
#include <QFont>

//implentation of lives of bruin
lives::lives(QGraphicsItem *parent): QGraphicsTextItem(parent)
{
    // initialize the life to 3
    num_lives = 3;

    // draw the text
    setPlainText(QString("Lives: ") + QString::number(num_lives)); // 3 lives at start
    setDefaultTextColor(Qt::red);
    setFont(QFont("chiller",22));
}

void lives::decrease()
{
    num_lives--;
    setPlainText(QString("Lives: ") + QString::number(num_lives));
    if ( num_lives == 0 )
            emit dead();

}

int lives::get_lives()
{
    return num_lives;
}

void lives::set_lives(int new_lives)
{
    num_lives = new_lives;
}
