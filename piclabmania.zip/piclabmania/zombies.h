#ifndef ZOMBIES_H
#define ZOMBIES_H

#include <QGraphicsPixmapItem>
#include <QGraphicsItem>
#include <QObject>
#include <QTimer>

class zombies: public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT

public:
    zombies(QGraphicsItem* parent = nullptr);
    QTimer * timer = new QTimer(this);

public slots:
    void move();

};

#endif // ZOMBIES_H
