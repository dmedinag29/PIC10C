
#include "holdingwidget.h"

//holds application together, switches from window to window

game *myGame;

//keeps track of mute button clicks
int countmute=0;

holdingwidget::holdingwidget(QWidget *parent) : QWidget(parent)
{
    main_layout = new QVBoxLayout;

    //add background music`
    music->setMedia(QUrl("qrc:/my/music.mp3"));
    music->play();

    //Sets Background
    QPixmap bkgnd(":/hallway/staircase.jpg");
    QPalette palette;
    //bkgnd = bkgnd.scaled(size(),Qt::IgnoreAspectRatio);
    palette.setBrush(QPalette::Background, bkgnd);
    this->setPalette(palette);

    //creates all windows
    widget_holder = new QStackedWidget;
    main_win = new MainWindow;

    //adds all your windows to our widget_holder!
    widget_holder->addWidget(main_win);
    instr_win = new InstrWindow;

    widget_holder->addWidget(instr_win);

    main_layout->addWidget(widget_holder);

    play_win = new PlayWindow;
    widget_holder->addWidget(play_win);

    inQ_win = new InputQuestion;
    widget_holder->addWidget(inQ_win);

    gi_win = new Gameintro;
    widget_holder->addWidget(gi_win);

    instr = new game_instr;
    widget_holder->addWidget(instr);

    myGame = new game;
    widget_holder->addWidget(myGame);

    final_win = new FinalWindow;
    widget_holder->addWidget(final_win);

     win_window = new win;
     widget_holder->addWidget(win_window);


    setLayout(main_layout);
    //Button connections for all windows
    connect(main_win->getButton(),SIGNAL(pressed()),this, SLOT(DisplayInstruWidget()));
    connect(instr_win->getButton(),SIGNAL(pressed()),this, SLOT(DisplayFirstWidget()));
    connect(main_win->getPlayButton(),SIGNAL(pressed()),this, SLOT(DisplayPlayWidget()));
    connect(main_win->getPlayButton(),SIGNAL(pressed()),this, SLOT(mytimerevent()));
    connect(main_win->muteButton(),SIGNAL(pressed()),this, SLOT(mute()));
    connect(play_win->getpushButton(), SIGNAL(pressed()),this, SLOT(DisplayinQWidget()));
    connect(play_win->getpushButton_2(), SIGNAL(pressed()),this, SLOT(wrong_answer()));
    connect(play_win->getpushButton_3(), SIGNAL(pressed()),this, SLOT(wrong_answer()));
    connect(play_win->getpushButton_4(), SIGNAL(pressed()),this, SLOT(wrong_answer()));
    connect(inQ_win->getButton(), SIGNAL(pressed()), this, SLOT(set_text()));
    connect(inQ_win->gethintbutton(), SIGNAL(pressed()), this, SLOT(show_hint()));
    connect(gi_win->getButton(), SIGNAL(pressed()), this, SLOT(DisplaygameInstr()));
    connect(instr->getButton(), SIGNAL(pressed()), this, SLOT(DisplaygamewindowWidget()));
    connect(final_win->getButton(), SIGNAL(pressed()), this, SLOT(end()));
    connect(inQ_win->getButton(),SIGNAL(pressed()),this,SLOT(check_answer(QString)));
    connect(myGame->myLives, SIGNAL(dead()), this, SLOT(DisplayFinalWidget()));
    connect(myGame->myScore, SIGNAL(win()), this, SLOT(DisplayWinWidget()));
    connect(win_window->getwinendButton(), SIGNAL(pressed()), this, SLOT(end()));


    //Automatically set shows main screen
    DisplayFirstWidget();
}

//Implementations of slots called when buttons pressed!
void holdingwidget::DisplayInstruWidget()
{
    widget_holder->setCurrentIndex(widget_holder->indexOf(instr_win));
}
void holdingwidget::DisplayFirstWidget()
{

    widget_holder->setCurrentIndex(widget_holder->indexOf(main_win));
}

void holdingwidget::DisplayPlayWidget()
{
    trial = 0;
    inQ_win->getlabel()->setStyleSheet("QLabel {font: 75 20pt Goudy Old Style;  color : white; }");
    play_win->getlabel()->setText("Please select an answer");
    widget_holder->setCurrentIndex(widget_holder->indexOf(play_win));
}

void holdingwidget::DisplayinQWidget()
{

    widget_holder->setCurrentIndex(widget_holder->indexOf(inQ_win));
}

void holdingwidget::DisplaygameintroWidget()
{

    widget_holder->setCurrentIndex(widget_holder->indexOf(gi_win));
}

//creates game w/ lives and score
void holdingwidget::DisplaygameInstr()
{
    myGame->myLives->num_lives = 3;
    myGame->myScore->myScore = 0;

    widget_holder->setCurrentIndex(widget_holder->indexOf(instr));
}

//starts game
void holdingwidget::DisplaygamewindowWidget()
{

    myGame->joe_bruin->left =true;
    myGame->joe_bruin->right =true;
    myGame->joe_bruin->space =true;

    myGame->timer->start(2000);
    myGame->timer2->start(1000);
    myGame->timer3->start(1000);


        widget_holder->setCurrentIndex(widget_holder->indexOf(myGame));
}

//stops game and shows loss window
void holdingwidget::DisplayFinalWidget()
{
    myGame->joe_bruin->left =false;
    myGame->joe_bruin->right =false;
    myGame->joe_bruin->space =false;

    myGame->timer->stop();
    myGame->timer2->stop();
    myGame->timer3->stop();


    trial = 0;
    inQ_win->getlabel()->setStyleSheet("QLabel {font: 75 20pt Goudy Old Style;  color : white; }");
    inQ_win->getlineedit()->setText("");
    inQ_win->getlabel()->setText("Please select an answer");


    //widget_holder->setCurrentIndex(0);
    widget_holder->setCurrentIndex(widget_holder->indexOf(final_win));



}

//stops game and shows win window
void holdingwidget::DisplayWinWidget()
{
    myGame->joe_bruin->left =false;
    myGame->joe_bruin->right =false;
    myGame->joe_bruin->space =false;

    myGame->timer->stop();
    myGame->timer2->stop();
    myGame->timer3->stop();

    trial = 0;
    inQ_win->getlabel()->setStyleSheet("QLabel {font: 75 20pt Goudy Old Style;  color : white; }");
     inQ_win->getlineedit()->setText("");
     inQ_win->getlabel()->setText("Please select an answer");
     //inQ_win->getlabel()->ststyleSheet()

    //widget_holder->setCurrentIndex(0);
    widget_holder->setCurrentIndex(widget_holder->indexOf(win_window));

}

//Input question window implemntation, updates text to show hint
void holdingwidget::show_hint()
{
    std::stringstream sstr;
    sstr << "Subtract 100 from 2019" << std::endl;
    std::string message = sstr.str();
    inQ_win->getlabel()->setStyleSheet("QLabel {font: 75 20pt Goudy Old Style;  color : white; }");
    inQ_win->getlabel()->setText(QString::fromStdString(message));
}

//updates text if wrong answer
void holdingwidget::wrong_answer()
{
    std::stringstream sstr;
    sstr << "Wrong answer. Try again. Attempt no: " << ++trial ;
    std::string message = sstr.str();
    inQ_win->getlabel()->setStyleSheet("QLabel {font: 75 20pt Goudy Old Style;  color : white; }");
    play_win->getlabel()->setText(QString::fromStdString(message));

}

//input text implentation
void holdingwidget::set_text()
{
    QString str = inQ_win->getlineedit()->text();
    check_answer(str);
}

//checks answer in input question
void holdingwidget::check_answer(QString str)
{
   trial = 0;
    if (str == "1919")
    {
        connect(inQ_win->getcontinuebutton(), SIGNAL(pressed()), this, SLOT(DisplaygameintroWidget()));
        std::stringstream sstr;
        sstr << "Right Answer. Press Continue button." << ++trial ;
        std::string message = sstr.str();
        inQ_win->getlabel()->setStyleSheet("QLabel {font: 75 20pt Goudy Old Style;  color : white; }");
        inQ_win->getlabel()->setText(QString::fromStdString(message));
    }
    else
    {
        std::stringstream sstr;
        sstr << "Wrong answer. Try again. Attempt no: " << ++trial ;
        std::string message = sstr.str();
        inQ_win->getlabel()->setStyleSheet("QLabel {font: 75 20pt Goudy Old Style;  color : white; }");
        inQ_win->getlabel()->setText(QString::fromStdString(message));

    }
}


//closes application
void holdingwidget::end()
{
   qApp->exit();
}

void holdingwidget::mute(){
    countmute++;
    if(countmute%2==0){
        music->play();
    }
    else {
        music->stop();
    }
}



