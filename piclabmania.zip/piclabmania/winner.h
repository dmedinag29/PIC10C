#ifndef WINNER_H
#define WINNER_H

#include <QWidget>
#include <QPushButton>
#include <QObject>

namespace Ui {
class winner;
}

class winner : public QWidget
{
    Q_OBJECT

public:
    explicit winner(QWidget *parent = nullptr);
    ~winner();
     QPushButton* getButton();


private:
    Ui::winner *ui;
};

#endif // WINNER_H
