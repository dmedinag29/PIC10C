#include "gameboard.h"

gameboard::gameboard()
{
    //map.load(":/images/pac_map_old.png");
    ball = new specks;
    power_up = new powerup;
    
    add_points(30, 30, 200, 30);
    add_points(250, 30, 420, 30);
    add_points(30, 90, 420, 90);
    add_points(30, 130, 110, 130);
    add_points(150, 130, 200, 130);
    add_points(250, 130, 300, 130);
    add_points(340, 130, 420, 130);
    add_points(150, 180, 300, 180);
    add_points(0, 230, 150, 230);
    add_points(300, 230, 450, 230);
    add_points(150, 270, 300, 270);
    add_points(30, 320, 200, 320);
    add_points(250, 320, 420, 320);
    add_points(30, 360, 60, 360);
    add_points(110, 360, 340, 360);
    add_points(390, 360, 420, 360);
    add_points(30, 410, 110, 410);
    add_points(150, 410, 200, 410);
    add_points(250, 410, 300, 410);
    add_points(340, 410, 420, 410);
    add_points(30, 450, 420, 450);
    
    add_points(30, 30, 30, 130);
    add_points( 30, 320, 30, 360);
    add_points(30, 410, 30, 450);
    add_points( 60, 360, 60, 410);
    add_points(110, 30, 110, 410);
    add_points( 150, 90, 150, 130);
    add_points(150, 180, 150, 320);
    add_points(150, 360, 150, 410);
    add_points( 200, 30, 200, 90);
    add_points(200, 135, 200, 180);
    add_points( 200, 320, 200, 360);
    add_points( 200, 410, 200, 450);
    add_points( 250, 30, 250, 90);
    add_points( 250, 135, 250, 180);
    add_points( 250, 320, 250, 360);
    add_points( 250, 410, 250, 450);
    add_points( 300, 90, 300, 130);
    add_points( 300, 180, 300, 320);
    add_points( 300, 360, 300, 410);
    add_points( 340, 30, 340, 410);
    add_points( 390, 360, 390, 410);
    add_points( 420, 30, 420, 130);
    add_points( 420, 320, 420, 360);
    add_points( 420, 410, 420, 450);
    QPoint p;
    QPoint p1,p2,p3,p4;
    p1.setX(30);
    p1.setY(450);
    p2.setX(30);
    p2.setY(35);
    p3.setX(420);
    p3.setY(35);
    p4.setX(420);
    p4.setY(450);
    powerup_pts.push_front(p1);
    powerup_pts.push_front(p2);
    powerup_pts.push_front(p3);
    powerup_pts.push_front(p4);
    
    
    // This is an algorithm found on pacman tutorials to set the balls corresponding a pacman map
    for (int i=0; i<450-1; i++)
    {
        for(int j=0;j<480-1;j++)
        {
            p.setX(i);
            p.setY(j);
    
            if(j%10==0 && i%10==0)
            {
                if (bruin_points.contains(p))
                {
                    if(p!=p1 && p!=p2 && p!=p3 && p!=p4)
                    {
                        if(p.x()>0)
                            ball_pts.push_front(p);
                    }
    
                 }
            }
        }
    }
    create_specks();
    }
    
    QRectF gameboard::boundingRect() const
    {
    return QRect(0,0,450,480); //This is how big the constraints for the map are
    }
    
    
    void gameboard::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
    {
    painter->drawPixmap(0,0,450,480,map);
    }
    
    
    void gameboard::create_specks()
    {
    //// Painter used to create points on the map
    QPainter painter;
    painter.begin(&map);
    painter.setRenderHint(QPainter::Antialiasing);
    painter.setPen(Qt::NoPen); // they don't need an outline
    painter.setBrush(Qt::white); // colour
    
    
    for(int i=0;i<ball_pts.size();i++){
    
        painter.drawEllipse(ball_pts[i].x(),ball_pts[i].y(),3,3);
    }
    for(int i=0;i<powerup_pts.size();i++){
    
        painter.setBrush(Qt::yellow);
        painter.drawEllipse(powerup_pts[i].x()-5,powerup_pts[i].y()-5,10,10);
    }
    }
    
    
    // This creates a path behind pacman
    bool gameboard::can_move(QPoint point)
    {
    
    for(int i=0;i<bruin_points.size();i++){
        if(bruin_points[i]==point)
        {
             return true;
         }
    }
    return false;
    }
    
    
    // This draws the path behind pacman with colour, but colour is set to black
    void gameboard::fill_points(int px, int py)
    {
    QPainter painter;
    QRect rec(px,py,3,3);
    QRect rec2(px-5,py-5,10,10);
    
    painter.begin(&map);
    painter.fillRect(rec,Qt::black); // producing a trail behind pacman
    
    // This will paint over the powerball points once pacman has rode over them
    if((px==powerup_pts[0].x() && py==powerup_pts[0].y())||
           (px==powerup_pts[1].x() && py==powerup_pts[1].y())||
           (px==powerup_pts[2].x() && py==powerup_pts[2].y())||
           (px==powerup_pts[3].x() && py==powerup_pts[3].y())){
       painter.fillRect(rec2,Qt::black);
    }
    painter.end();
    }
    
    void gameboard::set_ball_pts(QVector<QPoint> points)
    {
    ball->set_points(points);
    }
    
    void gameboard::set_powerup_pts(QVector<QPoint> points)
    {
    power_up->set_points(points);
    }
    // This locates where the points are behind pacman and push them to front.
    void gameboard::add_points(int x1, int y1, int x2, int y2)
    {
    QPoint p;
    
    if (x1 == x2)
            {
                if (y1 < y2)
                {
                    for (int y=y1; y<y2+1; y++)
                    {
                        p.setX(x1);
                        p.setY(y);
                        if (! bruin_points.contains(p)){
                            bruin_points.push_front(p);
                        }
    
                    }
                }
                else
                {
                    for (int y=y1; y>y2-1; y--)
                    {
                        p.setX(x1);
                        p.setY(y);
                        if (! bruin_points.contains(p)){
                            bruin_points.push_front(p);
                        }
                    }
                }
            }
            else
            {
                if (x1 < x2)
                {
                    for (int x=x1; x<x2+1; x++)
                    {
                        p.setX(x);
                        p.setY(y1);//= new QPoint(x1, y);
                        if (! bruin_points.contains(p)){
                            bruin_points.push_front(p);
                        }
                    }
                }
                else
                {
                    for (int x=x1; x>x2-1; x--)
                    {
                        p.setX(x);
                        p.setY(y1);//= new QPoint(x1, y);
                        if (! bruin_points.contains(p)){
                            bruin_points.push_front(p);
                        }
    
                    }
                }
            }
    
    }
    
    
    QVector<QPoint> gameboard::get_ball_pts()
    {
    return ball_pts;
    }
    
    QVector<QPoint> gameboard::get_powerup_pts()
    {
    return powerup_pts;
    }
    
