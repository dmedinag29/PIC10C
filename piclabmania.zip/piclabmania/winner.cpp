#include "winner.h"
#include "ui_winner.h"

winner::winner(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::winner)
{
    ui->setupUi(this);
}

winner::~winner()
{
    delete ui;
}

QPushButton* winner::getButton()
{
    return ui->pushButton;
}
