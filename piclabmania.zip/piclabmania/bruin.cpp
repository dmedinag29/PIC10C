#include "bruin.h"
#include "bomb.h"
#include <QGraphicsScene>
#include <QKeyEvent>

//Implenmentation of bruin class


//adds bruin and shot sound effect to application
bruin::bruin(QGraphicsItem *parent): QGraphicsPixmapItem(parent){
    shotSound = new QMediaPlayer();
    shotSound->setMedia(QUrl("qrc:/shoot/shot.mp3"));

    setPixmap(QPixmap("://bruin.png"));
}

//connects key press events
void bruin::keyPressEvent(QKeyEvent *event)
{
      if (event->key() == Qt::Key_Left)
      {
          if (pos().x() > 0)
              setPos(x()-20,y());
          left= true;
      }

      else if (event->key() == Qt::Key_Right)
      {
          if (pos().x() + 100 < 800)
              setPos(x()+20,y());
          right= true;
      }


      else if (event->key() == Qt::Key_Space)
      {
           // create a bullet
           bullet* my_bullet = new bullet();
           my_bullet->setPos(x(),y());
           scene()->addItem(my_bullet);
           space=true;

           if (shotSound->state() == QMediaPlayer::PlayingState)
                 shotSound->setPosition(0);
           else if (shotSound->state() == QMediaPlayer::StoppedState)
                 shotSound->play();
      }
}

//if key event is called spawns zombies
void bruin::create_zombie()
{    // create zombie
    if((left==true)&&(right==true)&&(space==true)){
            zombies * enemy = new zombies();
            scene()->addItem(enemy);
    }
    }

//if key event is called creates powerups
void bruin::create_powers()
{
    // create powers
    if((left==true)&&(right==true)&&(space==true)){
    powers* power = new powers();
    scene()->addItem(power);
    }
}

//if key event is called creates bomb
void bruin::create_bomb()
{
    // create bombs
    if((left==true)&&(right==true)&&(space==true)){
    bomb* bombs = new bomb();
    scene()->addItem(bombs);
    }
}



