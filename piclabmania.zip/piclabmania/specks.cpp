#include "specks.h"
#include "game_window.h"

specks::specks()
{
    speck_x=0;
    speck_y=0;
    speck_w=5;
    speck_h=5;

    create_speck();
}

QRectF specks::boundingRect() const
{
    return QRect(0, 0, 450, 550);
}

void specks::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    for(int i=0;i<points.size();i++){
        painter->drawPixmap( points[i].x(), points[i].y(), speck);
    }
}

void specks::draw_specks(QPainter *painter)
{
    for(int i=0;i<points.size();i++){
        painter->drawPixmap( points[i].x(), points[i].y(), speck);
    }
}

void specks::set_points(QVector<QPoint> points)
{
    this->points.clear();
    this->points=points;
}

void specks::removepoint(QPoint p)
{
 //
}

void specks::create_speck()
{
    QRect bounds = QRect(0, 0, 3, 3);
    QPainter painter;

    speck = QPixmap(bounds.size());
    speck.fill(Qt::transparent);
    painter.begin(&speck);

    painter.setRenderHint(QPainter::Antialiasing);
    painter.setPen(Qt::NoPen);
    painter.setBrush(Qt::white);
    painter.drawEllipse(0, 0, 3, 3);

}
