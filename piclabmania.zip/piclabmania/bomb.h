#ifndef BOMB_H
#define BOMB_H

#include <QGraphicsPixmapItem>
#include <QGraphicsItem>
#include <QObject>

class bomb: public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT

public:
    bomb(QGraphicsItem* parent = nullptr);

public slots:
    void move();

};
#endif // BOMB_H
