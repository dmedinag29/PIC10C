This desktop application requires Qt Software download.
To instal Qt:
1. go to https://www.qt.io/download
2. follow the instructions on the website to download the latest version of Qt.

to download Qt, you do not need any other programs downloaded.
Use Qt Desktop Configuration Kit to configure the project.


Limitations:
Window size is constant.
update on number of lives lags.
mute button exists only in the first window.
shot sound is not mutable.

Authors:
Clara Vamvulescu
Daniel Medina
Ece Ograg
