#ifndef PLAYWINDOW_H
#define PLAYWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QLabel>

namespace Ui {
class PlayWindow;
}

class PlayWindow : public QMainWindow
{
    Q_OBJECT

    public:
        explicit PlayWindow(QWidget *parent = nullptr);
        ~PlayWindow();
    QPushButton* getpushButton();
    QPushButton* getpushButton_2();
    QPushButton* getpushButton_3();
    QPushButton* getpushButton_4();
    QLabel* getlabel();


    private:
        Ui::PlayWindow *ui;
};

#endif // PLAYWINDOW_H
