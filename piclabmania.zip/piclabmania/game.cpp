#include "game.h"
#include <QTimer>
#include <QApplication>
#include <QGraphicsTextItem>
#include <QFont>
#include <QBrush>
#include <QImage>
#include <QMediaPlayer>
#include "zombies.h"
#include "powers.h"
#include"bomb.h"


//implementaion of game
game::game(QWidget *parent)
{  
    // create the scene
    scene = new QGraphicsScene();
    scene->setSceneRect(0,0,800,600); // make the scene 800x600 instead of infinity by infinity (default)
    setStyleSheet("background-color:black;");

    // make the newly created scene the scene to visualize (since Game is a QGraphicsView Widget,
    // it can be used to visualize scenes)
    setScene(scene);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setFixedSize(900,600); // was at 1500,1500

    // create the player
    joe_bruin = new bruin();
    joe_bruin->setPos(350,475); // TODO generalize to always be in the middle bottom of screen
    // make the player focusable and set it to be the current focus
    joe_bruin->setFlag(QGraphicsItem::ItemIsFocusable);
    joe_bruin->setFocus();
    // add the player to the scene
    scene->addItem(joe_bruin);

    // create the score/lives
    myScore = new score();
    myScore->myScore = 0;
    scene->addItem(myScore);
    myLives = new lives();
    myLives->num_lives = 3;
    myLives->setPos(myLives->x(),myLives->y()+60);
    scene->addItem(myLives);

    //creates timer that spwans zombies, power ups, bombs
    timer = new QTimer();
    timer2 = new QTimer();
    timer3 = new QTimer();

    QObject::connect(zombietimer,SIGNAL(timeout()),enemies,SLOT(enemies->move()));


    QObject::connect(timer,SIGNAL(timeout()),joe_bruin,SLOT(create_zombie()));
    QObject::connect(timer3,SIGNAL(timeout()),joe_bruin,SLOT(create_powers()));
    QObject::connect(timer2,SIGNAL(timeout()),joe_bruin,SLOT(create_bomb()));



    //QMediaPlayer * music = new QMediaPlayer();

    show();
}

//ends application when called
void game::end()
{
    QCoreApplication::quit();
}
