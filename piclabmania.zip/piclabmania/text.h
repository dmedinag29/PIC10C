#ifndef TEXT_H
#define TEXT_H

#include <QPainter>
#include <QGraphicsItem>
#include <QGraphicsScene>

class text : public QGraphicsItem
{
public:
    text();
    QRectF boundingRect()const;
    void game_over(bool over);
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *options, QWidget *widget);
    bool over, playing, paused;
    int x, y, w, h, score, timeElapsed;

private:
    QTimer *timer;
};

#endif // TEXT_H
