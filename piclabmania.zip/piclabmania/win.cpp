#include "win.h"
#include "ui_win.h"
#include "bruin.h"
#include <QTimer>

//win window defined, implented using UI
win::win(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::win)
{
    ui->setupUi(this);

}

win::~win()
{
    delete ui;
}

QPushButton* win::getwinendButton(){
    return ui->winend_button;
}
