#ifndef POWERS_H
#define POWERS_H

#include <QGraphicsPixmapItem>
#include <QGraphicsItem>
#include <QObject>

class powers: public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT

public:
    powers(QGraphicsItem* parent = nullptr);

public slots:
    void move();

};

#endif // POWERS_H
