//#include "myfinalgame.h"
//#include "ui_myfinalgame.h"
//#include <QTimer>
//#include <QGraphicsTextItem>
//#include <QFont>
//#include <QMediaPlayer>
//#include "zombies.h"


//myfinalgame::myfinalgame(QWidget *parent)
//{
//    // create the scene
//    scene = new QGraphicsScene();
//    scene->setSceneRect(0,0,800,600); // make the scene 800x600 instead of infinity by infinity (default)

//    // make the newly created scene the scene to visualize (since Game is a QGraphicsView Widget,
//    // it can be used to visualize scenes)
//    setScene(scene);
//    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
//    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
//    setFixedSize(800,600);

//    // create the player
//    joe_bruin = new bruin();
//    joe_bruin->setRect(0,0,100,100); // change the rect from 0x0 (default) to 100x100 pixels
//    joe_bruin->setPos(400,500); // TODO generalize to always be in the middle bottom of screen
//    // make the player focusable and set it to be the current focus
//    joe_bruin->setFlag(QGraphicsItem::ItemIsFocusable);
//    joe_bruin->setFocus();
//    // add the player to the scene
//    scene->addItem(joe_bruin);

//    // create the score/lives
//    myScore = new score();
//    scene->addItem(myScore);
//    myLives = new lives();
//    myLives->setPos(myLives->x(),myLives->y()+25);
//    scene->addItem(myLives);

//    //create zombies
//    QTimer * timer = new QTimer();
//    QObject::connect(timer,SIGNAL(timeout()),joe_bruin,SLOT(create_zombie()));
//    timer->start(2000);

//    QMediaPlayer * music = new QMediaPlayer();
//     //music->setMedia(QUrl("qrc:/sounds/bgsound.mp3"));
//     //music->play();

//    show();
//}


