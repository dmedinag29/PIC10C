#ifndef INPUTQUESTION_H
#define INPUTQUESTION_H

#include <QWidget>
#include <QPushButton>
#include <QLineEdit>
#include <QLabel>

namespace Ui {
class InputQuestion;
}

class InputQuestion : public QWidget
{
    Q_OBJECT

public:
    explicit InputQuestion(QWidget *parent = nullptr);
    ~InputQuestion();
     QPushButton* getButton();
     QPushButton* getcontinuebutton();
     QPushButton* gethintbutton();
     QLineEdit* getlineedit();
     QLabel* getlabel();


private:
    Ui::InputQuestion *ui;

};

#endif // INPUTQUESTION_H
