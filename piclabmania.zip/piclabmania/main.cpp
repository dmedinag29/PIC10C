#include "mainwindow.h"
#include <QApplication>
#include"holdingwidget.h"

//calls application!
int main(int argc, char *argv[])
{
    //Class heiarchy formatted as a stack widget, see holdingwidget.cpp for implementation!

    QApplication a(argc, argv);
    holdingwidget h;


    double x=h.width()*1.33;
    double y=h.height()*1.3;
    h.setFixedSize(x,y);
    h.show();


    return a.exec();
}
