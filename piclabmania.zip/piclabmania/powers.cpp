#include "powers.h"
#include "game.h"
#include <QGraphicsScene>
#include <QList>
#include <QTimer>
#include <stdlib.h>

//defines powerups!
extern game *myGame;

//defines powerups to spawn randomly
powers::powers(QGraphicsItem *parent): QObject(), QGraphicsPixmapItem(parent)
{
    int random_number = rand() % 750;
    setPos(random_number,0);

    // draw powerups/powerdowns
    setPixmap(QPixmap(":/figures/powerup.png"));


    // connect
    QTimer * timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(move()));

    timer->start(100);

}

//makes powerups fall
void powers::move()
{
    if((myGame->joe_bruin->left==true)&&(myGame->joe_bruin->right==true)&&(myGame->joe_bruin->space==true)){

    // move power down
       setPos(x(),y()+10);

    // destroy power when it goes out of the screen
    if (pos().y() > 1200)
    {
        //decrease the health
        //myGame->myScore->increase_powerups();

        scene()->removeItem(this);
        delete this;
    }
    }
}
