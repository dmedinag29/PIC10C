#ifndef LIVES_H
#define LIVES_H

#include <QGraphicsTextItem>
#include <QObject>

class lives: public QGraphicsTextItem
{
     Q_OBJECT
public:
    lives(QGraphicsItem * parent = nullptr);
    void decrease();
    int get_lives();
    void set_lives(int x);
    int num_lives;;
signals:
    void dead();
private:


};

#endif // LIVES_H
