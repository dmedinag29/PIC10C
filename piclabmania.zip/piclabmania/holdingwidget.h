#ifndef HOLDINGWIDGET_H
#define HOLDINGWIDGET_H

#include <QWidget>
#include <QStackedWidget>
#include <QLayout>
#include "mainwindow.h"
#include "inputquestion.h"
#include "finalwindow.h"
#include "game.h"
#include <sstream>
#include <QMediaPlayer>
#include <QTimer>
#include "gameintro.h"
#include "win.h"
#include "game_instr.h"
#include "zombies.h"
#include <QApplication>


class holdingwidget : public QWidget
{
    Q_OBJECT
public:
    explicit holdingwidget(QWidget *parent = nullptr);

public slots:
    void DisplayInstruWidget();
    void DisplayFirstWidget();
    void DisplayPlayWidget();
    void DisplayinQWidget();
    void DisplaygameintroWidget();
    void DisplaygameInstr();
    void DisplaygamewindowWidget();
    void DisplayFinalWidget();
    void DisplayWinWidget();
    void wrong_answer();
    void set_text();
    void check_answer(QString);
    void show_hint();
    void end();
    void mute();





private:
    QStackedWidget* widget_holder = nullptr;
    QVBoxLayout* main_layout = nullptr;
    MainWindow* main_win = nullptr;
    InstrWindow* instr_win = nullptr;
    PlayWindow* play_win = nullptr;
    InputQuestion* inQ_win = nullptr;
    Gameintro* gi_win = nullptr;
    game_instr *instr = nullptr;
    FinalWindow* final_win= nullptr;
    win* win_window = nullptr;
    int trial = 0;
    QMediaPlayer* music = new QMediaPlayer();

};

#endif // HOLDINGWIDGET_H
