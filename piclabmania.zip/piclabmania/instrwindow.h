#ifndef INSTRWINDOW_H
#define INSTRWINDOW_H

#include <QDialog>
#include <QPixmap>

namespace Ui
{
    class InstrWindow;
}

class InstrWindow : public QDialog
{
    Q_OBJECT

    public:
        explicit InstrWindow(QWidget *parent = nullptr);
        ~InstrWindow();
    QPushButton* getButton();

    private:
        Ui::InstrWindow *ui;
};

#endif // INSTRWINDOW_H
