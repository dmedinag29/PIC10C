#ifndef SCORE_H
#define SCORE_H

#include <QGraphicsTextItem>
#include <QObject>

class score: public QGraphicsTextItem
{
    Q_OBJECT
public:
    score(QGraphicsItem * parent = nullptr);
    void increase();
    int get_score();
    void set_score(int x);
    void increase_powerups();
    int myScore;
signals:
    void win();
private:


};

#endif // SCORE_H

