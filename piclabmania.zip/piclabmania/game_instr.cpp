#include "game_instr.h"
#include "bruin.h"
#include "ui_game_instr.h"

//game instructions window defines here, implemented using UI
game_instr::game_instr(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::game_instr)
{
    ui->setupUi(this);
}

game_instr::~game_instr()
{
    delete ui;
}
QPushButton* game_instr::getButton(){
    return ui->pushButton;
}
