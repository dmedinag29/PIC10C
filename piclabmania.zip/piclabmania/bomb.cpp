#include "bomb.h"
#include "game.h"
#include <QGraphicsScene>
#include <QList>
#include <QTimer>
#include <stdlib.h>


//Implenmentation of bomb class
extern game *myGame;

//creats bomb at random postion and class move funtion
bomb::bomb(QGraphicsItem *parent): QObject(), QGraphicsPixmapItem(parent)
{
    int random_number = rand() % 700;
    setPos(random_number,0);

    // draw powerups/powerdowns
    setPixmap(QPixmap(":/figures/powerdown.png"));

    // connect
    QTimer * timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(move()));

    timer->start(30);
}

//moves bomb down, as well as destroys it when it leaves the screen

void bomb::move()
{
    if((myGame->joe_bruin->left==true)&&(myGame->joe_bruin->right==true)&&(myGame->joe_bruin->space==true)){

    // move power down
       setPos(x(),y()+10);

    // destroy bomb when it goes out of the screen
    if (pos().y() > 800)
    {
        //decrease the health
        //myGame->myLives->decrease();

        scene()->removeItem(this);
        delete this;
    }
    }
}
