#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QPixmap>
#include "instrwindow.h"
#include "playwindow.h"

namespace Ui
{
    class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

    public:
        explicit MainWindow(QWidget *parent = nullptr);
        ~MainWindow();

    public slots:
      void openInstrWindow();
      void openPlayWindow();
      QPushButton* getButton();
      QPushButton* getPlayButton();
      QPushButton* muteButton();

    private:
      InstrWindow *instr_win;
      PlayWindow *play_win;

    public:
        Ui::MainWindow *ui;

};


#endif // MAINWINDOW_H
