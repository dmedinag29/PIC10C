#include "gameintro.h"
#include "ui_gameintro.h"

//intro to game window, implented through UI
Gameintro::Gameintro(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Gameintro)
{
    ui->setupUi(this);

    setStyleSheet("Gameintro {background-image: url(:/bg/background.png);}");

}

Gameintro::~Gameintro()
{
    delete ui;
}

QPushButton* Gameintro::getButton()
{
    return ui->go_to_game_button;
}
