#ifndef GAMEBOARD_H
#define GAMEBOARD_H
#include <QPainter>
#include <QGraphicsScene>
#include <QVector>
#include "specks.h"
#include "powerup.h"


class gameboard : public QGraphicsItem
{
public:
    gameboard();
    specks *ball;
    powerup *power_up;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
    QRectF boundingRect() const;
    void advance();
    void create_specks();
    void add_points(int, int, int, int);
    bool can_move(QPoint);
    void fill_points(int pacx,int pacy);
    void set_ball_pts(QVector<QPoint> points);
    void set_powerup_pts(QVector<QPoint> points);

    //void change_geo() { prepareGeometryChange(); }

    QVector<QPoint> get_ball_pts();
    QVector<QPoint> get_powerup_pts();
    
    QPixmap map;
    QVector<QPoint> bruin_points, ball_pts, powerup_pts;
};

#endif // GAMEBOARD_H
