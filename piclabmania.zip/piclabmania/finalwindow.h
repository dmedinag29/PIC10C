#ifndef FINALWINDOW_H
#define FINALWINDOW_H

#include <QWidget>
#include <QPushButton>

namespace Ui {
class FinalWindow;
}

class FinalWindow : public QWidget
{
    Q_OBJECT

public:
    explicit FinalWindow(QWidget *parent = nullptr);
    ~FinalWindow();
    QPushButton* getButton();

private:
    Ui::FinalWindow *ui;
};

#endif // FINALWINDOW_H
