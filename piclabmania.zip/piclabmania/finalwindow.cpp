#include "finalwindow.h"
#include "bruin.h"
#include "ui_finalwindow.h"
#include <QTimer>

//defines final window, implented using UI
FinalWindow::FinalWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FinalWindow)
{
    ui->setupUi(this);
}

FinalWindow::~FinalWindow()
{
    delete ui;
}

//returns ui button
QPushButton* FinalWindow::getButton(){
    return ui->end_button;
}
