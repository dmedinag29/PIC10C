#include "inputquestion.h"
#include "ui_inputquestion.h"

//creates input question window, implented using UI
InputQuestion::InputQuestion(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::InputQuestion)
{
    ui->setupUi(this);
    setStyleSheet("InputQuestion {border-image: url(:/hallway/hallway.jpg);}");
}

InputQuestion::~InputQuestion()
{
    delete ui;
}


QPushButton* InputQuestion::getButton(){
    return ui->answerButton2;
}

QPushButton* InputQuestion::gethintbutton(){
    return ui->hintbutton;
}

QLineEdit* InputQuestion::getlineedit(){
    return ui->userinput;
}

QLabel* InputQuestion::getlabel(){
    return ui->label_2;
}

QPushButton* InputQuestion::getcontinuebutton(){
    return ui->pushButton;
}

