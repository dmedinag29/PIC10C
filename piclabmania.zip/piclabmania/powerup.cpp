#include "powerup.h"
#include "game_window.h"

powerup::powerup()
{
    powerup_x=0;
    powerup_y=0;
    powerup_w=5;
    powerup_h=5;

    create_powerup();
}

QRectF powerup::boundingRect() const
{
    return QRect(0, 0, 450, 550);
}

void powerup::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    //paint instance of a powerup
    for(int i=0;i<points.size();i++){
        painter->drawPixmap(points[i].x()-5, points[i].y()-5, powerup_pixmap);
    }
}

void powerup::set_points(QVector<QPoint> points)
{
    //clears points before updating so that they don't double
    this->points.clear();
    this->points=points;
}

void powerup::draw(QPainter *painter)
{
    //Draws the powerups on the screen
    for(int i=0;i<points.size();i++){
        painter->drawPixmap(points[i].x()-5, points[i].y()-5, powerup_pixmap);
    }
}

void powerup::create_powerup()
{
    QRect bounds = QRect(0, 0, 10, 10);
    QPainter painter;

    powerup_pixmap = QPixmap(bounds.size());
    powerup_pixmap.fill(Qt::transparent);
    painter.begin(&powerup_pixmap);

    QPen pen=QPen(Qt::yellow);

    painter.setRenderHint(QPainter::Antialiasing);
    painter.setPen(pen);
    painter.setBrush(Qt::red);
    painter.drawEllipse(0, 0, 10, 10);
}
