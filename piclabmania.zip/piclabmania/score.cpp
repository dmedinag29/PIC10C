#include "score.h"
#include <QFont>

// score defined here!
score::score(QGraphicsItem *parent): QGraphicsTextItem(parent)
{
    // initialize the score to 0
    myScore = 0;

    // draw the text
    setPlainText(QString("Score: ") + QString::number(myScore)); // Score: 0
    setDefaultTextColor(Qt::blue);
    setFont(QFont("chiller",22));
}

//increaces score used for when zombies killed
void score::increase()
{
    myScore+=50;
    setPlainText(QString("Score: ") + QString::number(myScore)); //score: 50
    if ( myScore == 1000 )
            emit win();
}

//increases score used for when powerups are hit
void score::increase_powerups()
{
    myScore+=25;
    setPlainText(QString("Score: ") + QString::number(myScore));
    if ( myScore == 1000 )
            emit win();
}

int score::get_score()
{
    return myScore;
}

void score::set_score(int new_score)
{
    myScore = new_score;
}
