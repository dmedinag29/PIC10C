#ifndef GAME_WINDOW_H
#define GAME_WINDOW_H

#include <QDialog>
#include <QSoundEffect>
#include "gameboard.h"
#include "specks.h"
#include "zombies.h"
#include "powerup.h"
#include "bruin.h"
#include "text.h"

namespace Ui {
class game_window;
}

class game_window : public QDialog
{
    Q_OBJECT

public:
    explicit game_window(QWidget *parent = nullptr);
    ~game_window();
    
    void bruin_move();
    void az_move();
    void bz_move();
    void pz_move();
    void gz_move();
    void az_move_in_rect();
    void gz_move_in_rect();
    void bz_move_in_rect();
    void pz_move_in_rect();
    void check_lost();
    void retry();
    void delay();
    void start_game();
    void end_game();
    void pause();

    //characters
    bruin *joe_bruin;
    zombies *green_zombie;
    zombies *aqua_zombie;
    zombies *purple_zombie;
    zombies *blue_zombie;

    //board features
    gameboard *board;
    specks *ball;
    powerup *power_up;
    text *texts;
    QString label;
    
/// These integers contain values of location on screen and directions
    int bruin_x, bruin_y,dir,next_dir;
    int az_move_y, az_move_x, az_dir, next_az_dir;
    int gz_move_y, gz_move_x, gz_dir, next_gz_dir;
    int bz_move_y, bz_move_x, bz_dir, next_bz_dir;
    int pz_move_y, pz_move_x, pz_dir, next_pz_dir;
    
/// This contains bools for if the states they are in
    bool bruin_moving, az_moving, gz_moving, bz_moving, pz_moving;
    bool az_scared, gz_scared, bz_scared, pz_scared;
    bool g_zombie, p_zombie, b_zombie, a_zombie;
    bool start, playing, paused;
    
    int score, state3,state2,state1,state, scared_state,lives, starting;
    
    QVector<QPoint> ball_pts; // this allows to set the location on screen
    QVector<QPoint> powerup_pts;
    
    
public slots:
    void update();
    void update_zombies();
    
    
protected:  
    void keyPressEvent(QKeyEvent *event);

    
private slots:
    int timeoutTime() { return 1000 / (2); }
    void on_pauseButton_clicked();
    void on_controlsButton_clicked();

    
private:
    Ui::game_window *ui;
    QGraphicsScene *scene;
    QTimer *timer;
    QTimer *zombie_timer;

};


#endif // GAME_WINDOW_H
