#include "mainwindow.h"
#include "ui_mainwindow.h"


//main window defined, implented using UI
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setStyleSheet("MainWindow {border-image: url(:/hallway/staircase.jpg);}");

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::openInstrWindow()
{
    instr_win = new InstrWindow();
    instr_win->show();
}

void MainWindow::openPlayWindow()
{
    play_win = new PlayWindow();
    play_win->show();
}



QPushButton* MainWindow::getButton()
{
    return ui->instrButton;
}

QPushButton* MainWindow::getPlayButton()
{
    return ui->PlayButton;
}

QPushButton* MainWindow::muteButton()
{
    return ui->muteButton;
}

