#ifndef BRUIN_H
#define BRUIN_H

#include <QGraphicsPixmapItem>
#include <QGraphicsItem>
#include <QObject>
#include <QMediaPlayer>
#include "bullet.h"
#include "zombies.h"
#include "powers.h"
#include "bomb.h"

class bruin : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT

public:
    bruin(QGraphicsItem* parent = nullptr);
    void keyPressEvent(QKeyEvent * event);
    bool right;
    bool left;
    bool space;

public slots:
    void create_zombie();
    void create_powers();
    void create_bomb();
private:
      QMediaPlayer* shotSound;

      

};

#endif // BRUIN_H
