#include "playwindow.h"
#include "ui_playwindow.h"

//multiple choice window defined, implented using UI
PlayWindow::PlayWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::PlayWindow)
{
    ui->setupUi(this);
    setStyleSheet("PlayWindow {border-image: url(:/hallway/staircase.jpg);}");
}

PlayWindow::~PlayWindow()
{
    delete ui;
}

QPushButton* PlayWindow::getpushButton(){
    return ui->answer1;
}

QPushButton* PlayWindow::getpushButton_2(){
    return ui->answer2;
}

QPushButton* PlayWindow::getpushButton_3(){
    return ui->answer3;
}

QPushButton* PlayWindow::getpushButton_4(){
    return ui->answer4;
}

QLabel* PlayWindow::getlabel(){
    return ui->label_2;
}
