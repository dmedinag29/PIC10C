#ifndef GAME_INSTR_H
#define GAME_INSTR_H

#include <QWidget>
#include <QPushButton>

namespace Ui {
class game_instr;
}

class game_instr : public QWidget
{
    Q_OBJECT

public:
    explicit game_instr(QWidget *parent = nullptr);
    ~game_instr();
     QPushButton* getButton();

private:
    Ui::game_instr *ui;
};

#endif // GAME_INSTR_H
