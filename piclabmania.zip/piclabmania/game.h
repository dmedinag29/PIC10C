#ifndef GAME_H
#define GAME_H

#include <QGraphicsView>
#include <QGraphicsScene>
#include <QWidget>
#include <QObject>
#include "bruin.h"
#include "score.h"
#include "lives.h"


class game : public QGraphicsView
{
     Q_OBJECT
public:
    game(QWidget* parent = nullptr);
    QGraphicsScene* scene;
    bruin* joe_bruin =nullptr;
    score* myScore;
    lives* myLives;
    zombies* enemies;
    QTimer * timer = nullptr;
    QTimer * timer2 = nullptr;
    QTimer * timer3 = nullptr;
    QTimer * zombietimer = nullptr;



public slots:
    void end();

};

#endif // GAME_H
