#include "zombies.h"
#include "game.h"
#include <QGraphicsScene>
#include <QList>
#include <QTimer>
#include <stdlib.h>

//defines zombies for game!

extern game *myGame;

//spawns diffrent colored zombies at diffrent locations randomly
zombies::zombies(QGraphicsItem *parent): QObject(), QGraphicsPixmapItem(parent)
{
    //set random position
    int random_number = rand() % 600;
    setPos(random_number,0);

    // draw zombie
    int rand_num = rand() % 101;
    if (rand_num >= 75)
        setPixmap(QPixmap(":/aqua/aqua_down.png"));
    else if (rand_num >= 50)
        setPixmap(QPixmap(":/blue/blue_down.png"));
    else if (rand_num >= 25)
        setPixmap(QPixmap(":/green/green_down.png"));
    else
        setPixmap(QPixmap(":/purple/purple_down.png"));

    // connect
    connect(timer,SIGNAL(timeout()),this,SLOT(move()));

    timer->start(350);
}

//moves zombies down & destorys when out of screen
void zombies::move()
{
    if((myGame->joe_bruin->left==true)&&(myGame->joe_bruin->right==true)&&(myGame->joe_bruin->space==true)){
    // move zombie down
       setPos(x(),y()+25);

    // destroy zombie when it goes out of the screen
    if (pos().y() > 650)
    {
        //decrease the health
        myGame->myLives->decrease();

        scene()->removeItem(this);
        delete this;
    }
    }
}
