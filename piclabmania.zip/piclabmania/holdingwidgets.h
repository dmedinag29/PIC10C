#ifndef HOLDINGWIDGETS_H
#define HOLDINGWIDGETS_H

#include <QWidget>

namespace Ui {
class holdingwidgets;
}

class holdingwidgets : public QWidget
{
    Q_OBJECT

public:
    explicit holdingwidgets(QWidget *parent = nullptr);
    ~holdingwidgets();

private:
    Ui::holdingwidgets *ui;
};

#endif // HOLDINGWIDGETS_H
