#include "instrwindow.h"
#include "ui_instrwindow.h"

//defines instrution window, implented using UI
InstrWindow::InstrWindow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::InstrWindow)
{
    ui->setupUi(this);
    setStyleSheet("InstrWindow {border-image: url(:/hallway/staircase.jpg);}");
}

InstrWindow::~InstrWindow()
{
    delete ui;
}

QPushButton* InstrWindow::getButton(){
    return ui->BackButton;
}
