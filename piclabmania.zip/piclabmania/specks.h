#ifndef SPECKS_H
#define SPECKS_H
#include <QPainter>
#include <QGraphicsItem>
#include <QGraphicsScene>

class specks : public QGraphicsItem
{
public:
    specks();
    QRectF boundingRect() const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
    void draw_specks(QPainter *painter);
    void set_points(QVector<QPoint> points);
    void removepoint(QPoint p);
    void create_speck();

    int speck_x,speck_y,speck_w,speck_h;
    QPixmap speck;
    QRectF rect;
    QVector<QPoint> points;

};

#endif // SPECKS_H


