#include "bullet.h"
#include "zombies.h"
#include "powers.h"
#include "game.h"
#include <QTimer>
#include <QList>
#include <QGraphicsScene>

extern game* myGame;

//bullet class implementation
bullet::bullet(QGraphicsItem *parent): QObject(), QGraphicsPixmapItem(parent)
{
    //draws bullet
    setPixmap(QPixmap(":/figures/images.png"));

    //make/connect a timer to move() the bullet every so often
    QTimer * timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(move()));

    //start the timer
    timer->start(50);
}

//moves bullet up and checks collision w/ zombies, powerups, and bombs
void bullet::move()
{
       // if bullet collides with enemy, destroy both
       QList<QGraphicsItem *> colliding_items = collidingItems();
       for (int i = 0, n = colliding_items.size(); i < n; ++i){
           if (typeid(*(colliding_items[i])) == typeid(zombies))
           {
                myGame->myScore->increase();

                // remove them both
                scene()->removeItem(colliding_items[i]);
                scene()->removeItem(this);

                // delete them both
                delete colliding_items[i];
                delete this;

                return;
            }
           else if (typeid(*(colliding_items[i])) == typeid(powers))
           {
               //increases score
               myGame->myScore->increase_powerups();

                // remove them both
                scene()->removeItem(colliding_items[i]);
                scene()->removeItem(this);

                // delete them both
                delete colliding_items[i];
                delete this;

                return;
            }
           else if (typeid(*(colliding_items[i])) == typeid(bomb))
           {
                //decreaces life
               myGame->myLives->decrease();

                // remove them both
                scene()->removeItem(colliding_items[i]);
                scene()->removeItem(this);

                // delete them both
                delete colliding_items[i];
                delete this;

                return;
            }
        }

        // move bullet up
        setPos(x(),y()-30);
        if (pos().y() < 0)
        {
            scene()->removeItem(this);
            delete this;
        }
}
