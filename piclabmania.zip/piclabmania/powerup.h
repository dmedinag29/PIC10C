#ifndef POWERUP_H
#define POWERUP_H

#include <QPainter>
#include <QGraphicsItem>
#include <QGraphicsScene>

class powerup : public QGraphicsItem
{
public:
    powerup();
    QRectF boundingRect() const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
    void set_points(QVector<QPoint> points);
    void draw(QPainter *painter);
    void remove_point(QPoint p);

    void create_powerup();
    void change_geo() { prepareGeometryChange(); }

    int powerup_x,powerup_y,powerup_w,powerup_h;
    QVector<QPoint> points;
    QPixmap powerup_pixmap;
};
#endif // POWERUP_H
