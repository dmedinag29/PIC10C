#ifndef GAMEINTRO_H
#define GAMEINTRO_H

#include <QWidget>
#include <QPushButton>

namespace Ui {
class Gameintro;
}

class Gameintro : public QWidget
{
    Q_OBJECT

public:
    explicit Gameintro(QWidget *parent = nullptr);
    ~Gameintro();
    QPushButton* getButton();

private:
    Ui::Gameintro *ui;
};

#endif // GAMEINTRO_H
